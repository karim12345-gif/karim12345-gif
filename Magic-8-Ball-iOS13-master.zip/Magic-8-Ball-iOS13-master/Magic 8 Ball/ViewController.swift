//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Angela Yu on 14/06/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    // the array was created
    let ballArray = [#imageLiteral(resourceName: "ball1.png"),#imageLiteral(resourceName: "ball2.png"),#imageLiteral(resourceName: "ball3.png"),#imageLiteral(resourceName: "ball4.png"),#imageLiteral(resourceName: "ball5.png")]
    //figure out a way to change the Image View using code to display the ball3 image when the Ask Button is pressed.

    @IBAction func askButtonPressed(_ Sender:UIButton){
        
        //imageView.image = ballArray[2] // this will display the 3rd ball
        // ask for random ints
        imageView.image = ballArray.randomElement();
        
    }

}

